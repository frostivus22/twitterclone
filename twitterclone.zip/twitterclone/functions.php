<?php  

	session_start();



	$link = mysqli_connect("fdb17.biz.nf","2384197_twitter","twitter21","2384197_twitter");
	if (mysqli_connect_errno())
  {
  //echo "Failed to connect to MySQL: " . mysqli_connect_error(); <--error showing if database is not connected
  }


  if (isset($_GET['function'])){
  		if($_GET['function'] == "logout"){
  	session_unset();
  	}	
  }

  function time_since($since) {
    $chunks = array(
        array(60 * 60 * 24 * 365 , 'year'),
        array(60 * 60 * 24 * 30 , 'month'),
        array(60 * 60 * 24 * 7, 'week'),
        array(60 * 60 * 24 , 'day'),
        array(60 * 60 , 'hour'),
        array(60 , 'm'),
        array(1 , 's')
    );

    for ($i = 0, $j = count($chunks); $i < $j; $i++) {
        $seconds = $chunks[$i][0];
        $name = $chunks[$i][1];
        if (($count = floor($since / $seconds)) != 0) {
            break;
        }
    }

    $print = ($count == 1) ? '1 '.$name : "$count {$name}s";
    return $print;
	}




  function displayTweets($type){

  	global $link;


  	if($type == 'public'){

  		$whereClause = "";

  	}else if ($type == "isFollowing")

  	{
  		$query = "SELECT * FROM isFollowing WHERE follower = '".mysqli_real_escape_string($link, $_SESSION['id'])."' ";
  		$result = mysqli_query($link, $query);

  		$whereClause = "";

  		while ($row = mysqli_fetch_assoc($result)){

  			if($whereClause == "") {

  				$whereClause = "WHERE";
  			}
  			else {
  				$whereClause.= " OR ";

  			$whereClause.=" userid = ".$row['isFollow'];
  			}
  		}

  	}

  	else if ($type == "Mine"){

  		$whereClause = "WHERE userid =".mysqli_real_escape_string($link,$_SESSION['id']);

  	}
  	else if ($type == "search"){

  		echo '<p><h1>Showing results for : '.mysqli_real_escape_string($link,$_GET['q']).'</h1></p>';

  		$whereClause = "WHERE tweet LIKE '%".mysqli_real_escape_string($link,$_GET['q'])."%'";

  	}else if (is_numeric($type)){


  		$userquery = "SELECT * FROM user WHERE id = ".mysqli_real_escape_string($link,$type)." LIMIT 1";
  			$userQueryResult = mysqli_query($link, $userquery);
  			$user = mysqli_fetch_assoc($userQueryResult);

  			echo "<h2>".mysqli_real_escape_string($link,$user['email'])."'s Tweets</h2>";

  		$whereClause = "WHERE userid =".mysqli_real_escape_string($link,$type);


  	}


  	 $query = "SELECT * FROM tweets ".$whereClause." ORDER BY `datetime` DESC LIMIT 10";

  	$result = mysqli_query($link, $query);

  	if(mysqli_num_rows($result) == 0){

  		echo "there are no tweets to display";

  	} else {

  		while ($row = mysqli_fetch_assoc($result)){

  			$userquery = "SELECT * FROM user WHERE id = ".mysqli_real_escape_string($link,$row['userid'])." LIMIT 1";
  			$userQueryResult = mysqli_query($link, $userquery);
  			$user = mysqli_fetch_assoc($userQueryResult);

  			echo "<div class = 'tweet'><p><a href='?page=public&userid=".$user['id']."'>".$user['email']."</a><span class ='time'> ".time_since(time()-strtotime($row['datetime']))." ago</span> : </p>";

  			echo "<p>".$row['tweet']." <a class='toggleFollow' data-userId = '".$row['userid']."'> ";
  			$isFollowingquery = "SELECT * FROM isFollowing WHERE follower = '".mysqli_real_escape_string($link, $_SESSION['id'])."' AND isFollow  = '".mysqli_real_escape_string($link, $row['userid'])."' LIMIT 1";

			$isFollowingqueryresult = mysqli_query($link, $isFollowingquery);

			if(mysqli_num_rows($isFollowingqueryresult) > 0){

				echo "Unfollow";
				
			}else {

  			echo "Follow";

  			}
  			echo "</a></p></div>";

  			}

  		}


  }

  function displaySearch(){

  	echo '<form class="form-inline">
	  		<div class = "form-group">

	  		  <input type="hidden" name="page" value="search">
			  <input type="text" name="q" class="form-control mb-2 mr-sm-2 mb-sm-0" id="search" placeholder="Search">
			  </div>

			  <button class="btn btn-primary">Search Tweets</button>
			</form>';

  }

  function displayTweetBox(){

  	if($_SESSION['id'] > 0){

  	echo '<div id="tweetSuccess" class = "alert alert-success">Your Tweet Was Posted Successfully.</div> 
  	<div id="tweetFail" class = "alert alert-danger">Your Tweet posting failed.</div><div class="form">
	  		<div class="form-group">
    			<textarea class="form-control" id="tweetContent" rows="3">
    			</textarea>
  				</div>
			  <button class="btn btn-primary" id = "postTweetButton">Post Tweet!</button>
			</div>';

  	}

  }

  function displayUsers(){

  global $link;

  $query = "SELECT * FROM user LIMIT 10";

  	$result = mysqli_query($link, $query);

  	if(mysqli_num_rows($result) == 0){

  		echo "there are no users to display";

  	} else {

  		while ($row = mysqli_fetch_assoc($result)){

  			echo "<div class='tweet' <p><a href='?page=public&userid=".$row['id']."'>".$row['email']."</a></p></div>";

  			}

  }
}

	function uploadImage(){


		echo 
		'<div id="tweetSuccess" class = "alert alert-success">Your Tweet Was Posted Successfully.</div> 
  		<div id="tweetFail" class = "alert alert-danger">Your Tweet posting failed.</div>

  		<div class="form">

	  		<form class="form-group" enctype="multipart/form-data">
    			<input type="file" name ="file">
  				</form>
			  <button class="btn btn-primary" id = "uploadButton">Post Tweet!</button>
			</div>';

	}

  


  



?>