<?php

error_reporting(0);

	include("functions.php");

	include("views/header.php");

	if($_GET['page'] == "timeline"){

		include("views/timeline.php");

	}

	else if($_GET['page'] == "mytweets"){

		include("views/mytweets.php");

	}

	else if($_GET['page'] == "search"){

		include("views/search.php");

	}
	else if($_GET['page'] == "public"){

		include("views/public.php");

	} 
	else {

	include("views/home.php");

	}

	include("views/footer.php");

	

?>