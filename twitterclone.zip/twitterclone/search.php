<div class="container mainContainer"> 

<div class="row">
  <div class="col-md-8">
  	
  <h2>Tweets for you</h2>

  <?php displayTweets('search'); ?>


  </div>
  <div class="col-md-4">
  	

  <?php displaySearch(); ?>

  <hr>

  <?php displayTweetBox(); ?>



  </div>
</div>


</div>