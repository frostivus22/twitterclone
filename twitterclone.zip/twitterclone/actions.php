<?php

	include ("functions.php");




	if($_GET['action'] == "loginSignUp"){

		$error = "";

		if(!$_POST['email']){

			$error = "An email address is required";
		}
		else if(!$_POST['password']){

			$error = "A password is required";

		} 

		else if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) == false){
			$error = "Please enter valid email";

		}

		if($error != ""){
			echo $error;
			exit();
		}



		if ($_POST['loginActive'] == "0"){

			$query = "SELECT * FROM user WHERE email = '".mysqli_real_escape_string($link, $_POST['email'])."' LIMIT 1 ";

			$result = mysqli_query($link, $query);

			if(mysqli_num_rows($result) != 0){ 

				$error = "that email is already taken";
			}

			else{

				$query = "INSERT INTO user(`email`, `pass`) VALUES ('".mysqli_real_escape_string($link, $_POST['email'])."',
				 '".mysqli_real_escape_string($link, $_POST['password'])."')";
			}

			if(mysqli_query($link, $query)){
				
				$_SESSION['id'] = mysqli_insert_id($link);

				$query = "UPDATE user SET pass = '". md5(md5($_SESSION['id']).$_POST['password']) ."' WHERE id = ".$_SESSION['id']." LIMIT 1";

				mysqli_query($link, $query);

				echo 1;

				

			}
			else{
				$error = "couldnt create user";
			}


		}

		else {

			$query = "SELECT * FROM user WHERE email = '".mysqli_real_escape_string($link, $_POST['email'])."' LIMIT 1";

			$result = mysqli_query($link, $query);

			$row = mysqli_fetch_assoc($result);

				if($row['pass'] == md5(md5($row['id']).$_POST['password'])) {

					

					echo 1;

					$_SESSION['id'] = $row['id'];
					
				}

				else {

					$error ="could not find email and password combination";
				} 
			

		}



		if($error != ""){
			echo $error;
			exit();
		}



	}

	if($_GET['action'] == "toggleFollow"){

		$query = "SELECT * FROM isFollowing WHERE follower = '".mysqli_real_escape_string($link, $_SESSION['id'])."' AND isFollow  = '".mysqli_real_escape_string($link, $_POST['userid'])."' LIMIT 1";

		$result = mysqli_query($link, $query);

		if(mysqli_num_rows($result) > 0){ 

				$row = mysqli_fetch_assoc($result);

				mysqli_query($link, "DELETE FROM isFollowing WHERE id = '".mysqli_real_escape_string($link, $row['id'])."' LIMIT 1");

				echo "1";
		}

		else {
			$row = mysqli_fetch_assoc($result);

				mysqli_query($link, "INSERT INTO isFollowing (`follower`, `isFollow`) VALUES(".mysqli_real_escape_string($link, $_SESSION['id']).", ".mysqli_real_escape_string($link, $_POST['userid'])." ) ");

				echo "2";

		}




	}

	if($_GET['action'] == "postTweet"){

		if(!$_POST['tweetContent']){

		echo "your Tweet is empty";

		}
		else if(strlen($_POST['tweetContent']) > 140)
		{

		echo "tweet too long";

		}else {

			mysqli_query($link, "INSERT INTO tweets (`tweet`, `userid`, `datetime`) VALUES('".mysqli_real_escape_string($link, $_POST['tweetContent'])."', ".mysqli_real_escape_string($link, $_SESSION['id']).", NOW()) ");
			echo "1";

		}



	}







?>